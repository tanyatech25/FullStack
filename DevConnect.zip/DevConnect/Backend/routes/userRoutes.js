const express = require("express");
const router = express.Router();

const protect = require("../middlewares/authMiddleware");

// Protected route
router.get("/profile", protect, (req, res) => {
  res.json({
    message: "Protected route accessed",
    user: req.user,
  });
});

module.exports = router;